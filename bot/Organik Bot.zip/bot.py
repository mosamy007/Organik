import discord
from discord.ext import commands
from dotenv import load_dotenv
import os

load_dotenv()

TOKEN = os.getenv("TOKEN")

intents = discord.Intents.default()

bot = commands.Bot(command_prefix="!", intents=intents)

DESCRIPTION = """
# Welcome!

Please read the rules.

• Rule 1
• Rule 2
• Rule 3

Have fun!
"""

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.command()
@commands.has_permissions(administrator=True)
async def pinall(ctx):

    for channel in ctx.guild.text_channels:

        try:

            found = None

            async for message in channel.history(limit=100):

                if (
                    message.author == bot.user
                    and DESCRIPTION in message.content
                ):
                    found = message
                    break

            if found:

                await found.edit(content=DESCRIPTION)

                if not found.pinned:
                    await found.pin()

            else:

                msg = await channel.send(DESCRIPTION)
                await msg.pin()

        except Exception as e:
            print(channel.name, e)

    await ctx.send("Done!")

bot.run(TOKEN)